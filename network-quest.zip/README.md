# Network Quest: The Race to Root Access

A fun, interactive networking quiz game designed for Ontario Grade 12 Computer Engineering students.

## Hosting
You can host it using GitHub Pages, Netlify, or Vercel.
